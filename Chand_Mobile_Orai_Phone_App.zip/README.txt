Chand Mobile Orai - phone-installable PWA.
Open index.html through a static web host (HTTPS), then use browser menu > Add to Home screen.
This build stores data locally on each phone. It is NOT yet the shared online team/database version.
